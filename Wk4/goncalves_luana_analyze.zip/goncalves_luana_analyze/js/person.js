/**
 * Created by the JavaScript Development Team
 * Class: PWA
 * Goal: Goal7
 * Name: Luana Goncalves
 * Activity: Analyze Objects.person (Pseudocode)
 */

//Make the the Person object globally for main.js: window.Person=Person

//Under Person object, declare jobs and actions and give them each an array with 4 or more tasks:Person.jobs=["teacher", "farmer","student","pilot"]; Person.actions = ["sleeping", "eating", "working"];

//Create four properties for the Person Constructor: name, action, job, and row
