/**
 * Created by the JavaScript Development Team
 * Class: PWA
 * Goal: Goal7
 * Name: Luana Goncalves
 * Activity: Analyze Objects.person (Pseudocode)
 */

//Pseudocode for main.js

//Create an array var name = [] and add 5 people names to be randomly selected.

//Create an object using a for loop using math.random that delivers 3 instances and adds these references into the people array.

//Make in the math.random formula sends to the constructor of person (new Person) and show the HTML row number it will be displayed  with the chosen name from the names array

// Create a function that returns person's name, job and webpage. Name the function "populateHTML"

//set up a conditional in the function that stop duplicate names from populating

// setInterval(runUpdate, 1000/30); -  this interval with control the amount of time the random name will be selected to every 30 min


// Once the people array have all the Person Instances, create a loop to run this function for each person: function runUpdate(){people.forEach(function(element){element.update();});


